package com.prady.sample.service;

import java.util.Map;

/**
 * @author Prady
 */
public interface K8Service {
    Map<String, Object> info();

}
