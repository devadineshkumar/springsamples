/**
 *
 */
package com.prady.sample.tx.service;

import com.prady.sample.tx.dto.ProductDTO;

/**
 * @author Prady
 *
 */
public interface ProductTxService {

    ProductDTO save(ProductDTO productDTO);
}
