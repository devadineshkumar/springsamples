package com.security.demo.service;


import com.security.demo.dto.JwtAuthResponse;
import com.security.demo.dto.SignInRequest;
import com.security.demo.dto.SignupRequest;
import com.security.demo.entity.User;

public interface AuthService {

    User signUp(SignupRequest signupRequest);

    JwtAuthResponse signin(SignInRequest signInRequest);

}
