package com.concurrent.test.coding;

class TestClass {

    public static void main(String[] args) {
        System.out.println("11");
    }
}
