package com.concurrent.test;

import java.util.UUID;

public class ContentVersionDto {
    private UUID otIdentifier;
    private String contentVersion;
    private String objectName;
    private UUID otFrameworkIdentifier;

}
