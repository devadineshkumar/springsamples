package com.security.demo.service.impl;

import com.security.demo.service.JWTService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.function.Function;

@Service
public class JWTServiceImpl implements JWTService {

    @Override
    public String generateToken(UserDetails username) {

        return Jwts.builder().subject(username.getUsername()).issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 24))
                .signWith(getSecret(), Jwts.SIG.HS256).compact();
    }

    private SecretKey getSecret() {
        byte[] key = Base64.getDecoder().decode("pnYkdZAGnRiUGoMvfwqWbuVdyPfH4odDxEqs1W3rS+eUe2GtInPEhd/nnQZt8ylHQh7lohsnbTvZHAKIbrh1vg==");
        return Keys.hmacShaKeyFor(key);
    }

    @Override
    public String extractUsername(String token) {
        return extractClaims(token, Claims::getSubject);
    }

    private <T> T extractClaims(String token, Function<Claims, T> claimResolver) {
        final Claims claims = extractClaims(token);
        return claimResolver.apply(claims);
    }

    private Claims extractClaims(String token) {
        try {
            return Jwts.parser()
                    .verifyWith(getSecret())
                    .build().parseSignedClaims(token).getPayload();
        } catch (JwtException | IllegalArgumentException e) {
            throw new SecurityException("Invalid JWT token", e);
        }
    }


    @Override
    public boolean isTokenValid(String token, String username) {
        try {
            Jws<Claims> claims = Jwts.parser().verifyWith(getSecret()).build().parseSignedClaims(token);
            Claims payload = claims.getPayload();

            if (username.equals(payload.getSubject()) && !payload.getExpiration().before(new Date())) {
                return true;
            }
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
        return false;
    }

    @Override
    public boolean isTokenExpired(String token) {
        return false;
    }

    @Override
    public String generateRefreshToken(Map<String, Object> extraClaims, UserDetails userCheck) {
        return Jwts.builder().claims(extraClaims)
                .subject(userCheck.getUsername())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 102400000))
                .signWith(getSecret(), Jwts.SIG.HS256)
                .compact();
    }

    public static void main(String[] args) {
        System.out.println("-------" + new String(Base64.getEncoder().encode("HiIamSecret".getBytes())));
        System.out.println("-------" + new String(Base64.getDecoder().decode("HiIamSecret".getBytes())));


        byte[] key = new byte[64]; // 256 bits
        new SecureRandom().nextBytes(key);
        String base64Key = Base64.getEncoder().encodeToString(key);
        System.out.println("Generated Secret Key: " + base64Key);

    }
}
