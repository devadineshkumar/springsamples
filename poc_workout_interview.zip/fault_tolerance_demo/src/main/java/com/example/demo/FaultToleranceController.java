package com.example.demo;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@Slf4j
@RestController
public class FaultToleranceController {

    private final Random random = new Random();

    @GetMapping("/unstable")
    @CircuitBreaker(name = "sampleCircuitBreaker", fallbackMethod = "fallback")
    @Retry(name = "sampleRetry")
    @RateLimiter(name = "sampleRateLimiter")
    public String unstableEndpoint() {
        log.info("unstableEndpoint called"); // Add this line to log the method call
        if (random.nextBoolean()) {
            throw new RuntimeException("Simulated failure");
        }
        return "Success!";
    }

    public String fallback(Throwable t) {
        return "Fallback response due to: " + t.getMessage();
    }
}
