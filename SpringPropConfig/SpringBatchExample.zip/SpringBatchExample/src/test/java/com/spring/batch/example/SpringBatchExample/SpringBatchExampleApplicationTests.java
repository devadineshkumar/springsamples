package com.spring.batch.example.SpringBatchExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
