package com.prady.sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFaultToleranceApplicationTests {

	@Test
	void contextLoads() {
	}

}
