package com.security.demo.service.impl;

import com.security.demo.dto.JwtAuthResponse;
import com.security.demo.dto.SignInRequest;
import com.security.demo.dto.SignupRequest;
import com.security.demo.entity.User;
import com.security.demo.enums.Role;
import com.security.demo.service.AuthService;
import com.security.demo.service.JWTService;
import com.security.demo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JWTService jwtService;

    @Override
    public User signUp(SignupRequest signupRequest) {
        UserDetails userCheck = userService.loadUserByUsername(signupRequest.getEmail());

        if (null != userCheck) {
            throw new RuntimeException("User already exists with email: " + signupRequest.getEmail());
        }

        User user = new User();
        user.setFirstName(signupRequest.getFirstName());
        user.setLastName(signupRequest.getLastName());
        user.setEmail(signupRequest.getEmail());
        user.setRole(Role.USER);
        user.setPassword(passwordEncoder.encode(signupRequest.getPassword()));
        return userService.createUser(user);
    }

    @Override
    public JwtAuthResponse signin(SignInRequest signInRequest) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(signInRequest.getEmail(),
                signInRequest.getPassword()));
        UserDetails userCheck = userService.loadUserByUsername(signInRequest.getEmail());
        var jwtToken = jwtService.generateToken(userCheck);
        var refreshToken = jwtService.generateRefreshToken(new HashMap<>(), userCheck);

        return JwtAuthResponse.builder()
                .jwtToken(jwtToken)
                .refreshToken(refreshToken)
                .build();
    }
}
