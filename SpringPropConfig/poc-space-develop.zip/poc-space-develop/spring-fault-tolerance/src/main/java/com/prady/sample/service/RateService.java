package com.prady.sample.service;

import com.prady.sample.dto.RateDTO;

/**
 * @author Prady
 */
public interface RateService {

    RateDTO invokeRateService(RateDTO rateDTO);
}
