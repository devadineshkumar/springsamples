package com.security.demo.service;

import org.springframework.security.core.userdetails.UserDetails;

import java.util.Map;

public interface JWTService {

    String generateToken(UserDetails username);

    String extractUsername(String token);

    boolean isTokenValid(String token, String username);

    boolean isTokenExpired(String token);

    String generateRefreshToken(Map<String, Object> extraClaims, UserDetails userCheck);
}
