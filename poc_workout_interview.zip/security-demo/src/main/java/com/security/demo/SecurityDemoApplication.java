package com.security.demo;

import com.security.demo.entity.User;
import com.security.demo.enums.Role;
import com.security.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.util.CollectionUtils;

import java.util.List;

@SpringBootApplication
public class SecurityDemoApplication implements CommandLineRunner {

	@Autowired
	private UserService userService;


	@Override
	public void run(String... args) throws Exception {

		List<User> result = userService.findAllByRole(Role.ADMIN);

		if (CollectionUtils.isEmpty(result)) {
			User user = new User();

			user.setFirstName("abc");
			user.setLastName("def");
			user.setEmail("abc@gmail.com");
			user.setRole(Role.ADMIN);
			user.setPassword(new BCryptPasswordEncoder().encode("admin"));

			userService.createUser(user);
		}
	}

	public static void main(String[] args) {
		SpringApplication.run(SecurityDemoApplication.class, args);
	}

}
