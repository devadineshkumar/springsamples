package com.prady.sample.mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDBDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
