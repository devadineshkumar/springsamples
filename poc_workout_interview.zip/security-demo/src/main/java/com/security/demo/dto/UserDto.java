package com.security.demo.dto;

import com.security.demo.enums.Role;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDto {
    private UUID id;

    @NotEmpty(message = "First Name should not be empty")
    private String firstName;
    private String lastName;
    private String email;
    private Role role;

    // Getters and setters
}

