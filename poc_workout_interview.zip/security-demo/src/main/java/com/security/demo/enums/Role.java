package com.security.demo.enums;

public enum Role {
    USER,
    ADMIN
}

